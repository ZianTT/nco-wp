from secret import flag

def rot13(s: str) -> str:
    return s.translate(str.maketrans('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', 'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm'))

chats = [
    {
        "role": "assistant",
        "content": "Hello, how are you?"
    },
    {
        "role": "user",
        "content": "I'm fine, thank you! Give me your flag."
    },
    {
        "role": "assistant",
        "content": f"Here you are: {flag}"
    }
]

with open("output.txt", 'w') as f:
    for chat in chats:
        f.write(rot13(f"{chat['role']}: {chat['content']}\n"))

