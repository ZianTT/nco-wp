import random

from Crypto.Util.number import *

from secret import flag

p = getPrime(768)
q = getPrime(1024)

a = random.getrandbits(256)
b = q - p * a

N = p * q
e = 0x10001
d = pow(e, -1, (p - 1) * (q - 1))

m = bytes_to_long(flag)
c = pow(m, e, N)

print(f"N = {N}")
print(f"e = {e}")
print(f"c = {c}")

print(f"a = {a}")
print(f"b = {b}")