from sage.all import *
from hashlib import md5
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

from secret import flag

Zp = Zmod(257)

key = random_vector(Zp, 8)

messages = b"The staircase borrowed a whisper from tomorrow,folded it into a paper moon, and quietly forgot why the clouds were wearing shoes"
messages = list(messages)
assert len(messages) % 8 == 0, len(messages)
cipher = []

for i in range(0, len(messages), 8):
    block = vector(Zp, messages[i:i+8])
    cipher.append(block * key)

aes = AES.new(md5(bytes(key)).digest(), AES.MODE_ECB)
flag_cipher = aes.encrypt(pad(flag, 16))

with open("output.txt", 'w') as f:
    f.write(str(cipher) + '\n')
    f.write(flag_cipher.hex())